====================
Your Final Fantacy Team
    Position              Name  Salary  AvgPointsPerGame
11        PG    Damian Lillard    8500            43.778
20     PG/SG      Devin Booker    7600            39.152
23        SF       Paul George    7400            38.260
30        PG   Dennis Schroder    6700            34.750
51         C      Jusuf Nurkic    5900            30.271
65     SF/PF  Robert Covington    5300            28.435
104     PF/C      John Collins    4400            23.983
110    SG/SF       Jeremy Lamb    4200            24.898
====================

INTEGER OPTIMAL SOLUTION FOUND
Time used:   0.0 secs
Memory used: 0.3 Mb (289095 bytes)
Writing MIP solution to 'C:\Users\BLAKEC~1\AppData\Local\Temp\tmp4noo4n4z.glpk.raw'...
202 lines were written
Model unknown

  Variables:
    x : Size=177, Index=x_index
        Key : Lower : Value : Upper : Fixed : Stale : Domain
          0 :     0 :   0.0 :     1 : False : False : Binary
          1 :     0 :   0.0 :     1 : False : False : Binary
          2 :     0 :   0.0 :     1 : False : False : Binary
          3 :     0 :   0.0 :     1 : False : False : Binary
          4 :     0 :   0.0 :     1 : False : False : Binary
          5 :     0 :   0.0 :     1 : False : False : Binary
          6 :     0 :   0.0 :     1 : False : False : Binary
          7 :     0 :   0.0 :     1 : False : False : Binary
          8 :     0 :   0.0 :     1 : False : False : Binary
          9 :     0 :   0.0 :     1 : False : False : Binary
         10 :     0 :   0.0 :     1 : False : False : Binary
         11 :     0 :   1.0 :     1 : False : False : Binary
         12 :     0 :   0.0 :     1 : False : False : Binary
         13 :     0 :   0.0 :     1 : False : False : Binary
         14 :     0 :   0.0 :     1 : False : False : Binary
         15 :     0 :   0.0 :     1 : False : False : Binary
         16 :     0 :   0.0 :     1 : False : False : Binary
         17 :     0 :   0.0 :     1 : False : False : Binary
         18 :     0 :   0.0 :     1 : False : False : Binary
         19 :     0 :   0.0 :     1 : False : False : Binary
         20 :     0 :   1.0 :     1 : False : False : Binary
         21 :     0 :   0.0 :     1 : False : False : Binary
         22 :     0 :   0.0 :     1 : False : False : Binary
         23 :     0 :   1.0 :     1 : False : False : Binary
         24 :     0 :   0.0 :     1 : False : False : Binary
         25 :     0 :   0.0 :     1 : False : False : Binary
         26 :     0 :   0.0 :     1 : False : False : Binary
         27 :     0 :   0.0 :     1 : False : False : Binary
         28 :     0 :   0.0 :     1 : False : False : Binary
         29 :     0 :   0.0 :     1 : False : False : Binary
         30 :     0 :   1.0 :     1 : False : False : Binary
         31 :     0 :   0.0 :     1 : False : False : Binary
         32 :     0 :   0.0 :     1 : False : False : Binary
         33 :     0 :   0.0 :     1 : False : False : Binary
         34 :     0 :   0.0 :     1 : False : False : Binary
         35 :     0 :   0.0 :     1 : False : False : Binary
         36 :     0 :   0.0 :     1 : False : False : Binary
         37 :     0 :   0.0 :     1 : False : False : Binary
         38 :     0 :   0.0 :     1 : False : False : Binary
         39 :     0 :   0.0 :     1 : False : False : Binary
         40 :     0 :   0.0 :     1 : False : False : Binary
         41 :     0 :   0.0 :     1 : False : False : Binary
         42 :     0 :   0.0 :     1 : False : False : Binary
         43 :     0 :   0.0 :     1 : False : False : Binary
         44 :     0 :   0.0 :     1 : False : False : Binary
         45 :     0 :   0.0 :     1 : False : False : Binary
         46 :     0 :   0.0 :     1 : False : False : Binary
         47 :     0 :   0.0 :     1 : False : False : Binary
         48 :     0 :   0.0 :     1 : False : False : Binary
         49 :     0 :   0.0 :     1 : False : False : Binary
         50 :     0 :   0.0 :     1 : False : False : Binary
         51 :     0 :   1.0 :     1 : False : False : Binary
         52 :     0 :   0.0 :     1 : False : False : Binary
         53 :     0 :   0.0 :     1 : False : False : Binary
         54 :     0 :   0.0 :     1 : False : False : Binary
         55 :     0 :   0.0 :     1 : False : False : Binary
         56 :     0 :   0.0 :     1 : False : False : Binary
         57 :     0 :   0.0 :     1 : False : False : Binary
         58 :     0 :   0.0 :     1 : False : False : Binary
         59 :     0 :   0.0 :     1 : False : False : Binary
         60 :     0 :   0.0 :     1 : False : False : Binary
         61 :     0 :   0.0 :     1 : False : False : Binary
         62 :     0 :   0.0 :     1 : False : False : Binary
         63 :     0 :   0.0 :     1 : False : False : Binary
         64 :     0 :   0.0 :     1 : False : False : Binary
         65 :     0 :   1.0 :     1 : False : False : Binary
         66 :     0 :   0.0 :     1 : False : False : Binary
         67 :     0 :   0.0 :     1 : False : False : Binary
         68 :     0 :   0.0 :     1 : False : False : Binary
         69 :     0 :   0.0 :     1 : False : False : Binary
         70 :     0 :   0.0 :     1 : False : False : Binary
         71 :     0 :   0.0 :     1 : False : False : Binary
         72 :     0 :   0.0 :     1 : False : False : Binary
         73 :     0 :   0.0 :     1 : False : False : Binary
         74 :     0 :   0.0 :     1 : False : False : Binary
         75 :     0 :   0.0 :     1 : False : False : Binary
         76 :     0 :   0.0 :     1 : False : False : Binary
         77 :     0 :   0.0 :     1 : False : False : Binary
         78 :     0 :   0.0 :     1 : False : False : Binary
         79 :     0 :   0.0 :     1 : False : False : Binary
         80 :     0 :   0.0 :     1 : False : False : Binary
         81 :     0 :   0.0 :     1 : False : False : Binary
         82 :     0 :   0.0 :     1 : False : False : Binary
         83 :     0 :   0.0 :     1 : False : False : Binary
         84 :     0 :   0.0 :     1 : False : False : Binary
         85 :     0 :   0.0 :     1 : False : False : Binary
         86 :     0 :   0.0 :     1 : False : False : Binary
         87 :     0 :   0.0 :     1 : False : False : Binary
         88 :     0 :   0.0 :     1 : False : False : Binary
         89 :     0 :   0.0 :     1 : False : False : Binary
         90 :     0 :   0.0 :     1 : False : False : Binary
         91 :     0 :   0.0 :     1 : False : False : Binary
         92 :     0 :   0.0 :     1 : False : False : Binary
         93 :     0 :   0.0 :     1 : False : False : Binary
         94 :     0 :   0.0 :     1 : False : False : Binary
         95 :     0 :   0.0 :     1 : False : False : Binary
         96 :     0 :   0.0 :     1 : False : False : Binary
         97 :     0 :   0.0 :     1 : False : False : Binary
         98 :     0 :   0.0 :     1 : False : False : Binary
         99 :     0 :   0.0 :     1 : False : False : Binary
        100 :     0 :   0.0 :     1 : False : False : Binary
        101 :     0 :   0.0 :     1 : False : False : Binary
        102 :     0 :   0.0 :     1 : False : False : Binary
        103 :     0 :   0.0 :     1 : False : False : Binary
        104 :     0 :   1.0 :     1 : False : False : Binary
        105 :     0 :   0.0 :     1 : False : False : Binary
        106 :     0 :   0.0 :     1 : False : False : Binary
        107 :     0 :   0.0 :     1 : False : False : Binary
        108 :     0 :   0.0 :     1 : False : False : Binary
        109 :     0 :   0.0 :     1 : False : False : Binary
        110 :     0 :   1.0 :     1 : False : False : Binary
        111 :     0 :   0.0 :     1 : False : False : Binary
        112 :     0 :   0.0 :     1 : False : False : Binary
        113 :     0 :   0.0 :     1 : False : False : Binary
        114 :     0 :   0.0 :     1 : False : False : Binary
        115 :     0 :   0.0 :     1 : False : False : Binary
        116 :     0 :   0.0 :     1 : False : False : Binary
        117 :     0 :   0.0 :     1 : False : False : Binary
        118 :     0 :   0.0 :     1 : False : False : Binary
        119 :     0 :   0.0 :     1 : False : False : Binary
        120 :     0 :   0.0 :     1 : False : False : Binary
        121 :     0 :   0.0 :     1 : False : False : Binary
        122 :     0 :   0.0 :     1 : False : False : Binary
        123 :     0 :   0.0 :     1 : False : False : Binary
        124 :     0 :   0.0 :     1 : False : False : Binary
        125 :     0 :   0.0 :     1 : False : False : Binary
        126 :     0 :   0.0 :     1 : False : False : Binary
        127 :     0 :   0.0 :     1 : False : False : Binary
        128 :     0 :   0.0 :     1 : False : False : Binary
        129 :     0 :   0.0 :     1 : False : False : Binary
        130 :     0 :   0.0 :     1 : False : False : Binary
        131 :     0 :   0.0 :     1 : False : False : Binary
        132 :     0 :   0.0 :     1 : False : False : Binary
        133 :     0 :   0.0 :     1 : False : False : Binary
        134 :     0 :   0.0 :     1 : False : False : Binary
        135 :     0 :   0.0 :     1 : False : False : Binary
        136 :     0 :   0.0 :     1 : False : False : Binary
        137 :     0 :   0.0 :     1 : False : False : Binary
        138 :     0 :   0.0 :     1 : False : False : Binary
        139 :     0 :   0.0 :     1 : False : False : Binary
        140 :     0 :   0.0 :     1 : False : False : Binary
        141 :     0 :   0.0 :     1 : False : False : Binary
        142 :     0 :   0.0 :     1 : False : False : Binary
        143 :     0 :   0.0 :     1 : False : False : Binary
        144 :     0 :   0.0 :     1 : False : False : Binary
        145 :     0 :   0.0 :     1 : False : False : Binary
        146 :     0 :   0.0 :     1 : False : False : Binary
        147 :     0 :   0.0 :     1 : False : False : Binary
        148 :     0 :   0.0 :     1 : False : False : Binary
        149 :     0 :   0.0 :     1 : False : False : Binary
        150 :     0 :   0.0 :     1 : False : False : Binary
        151 :     0 :   0.0 :     1 : False : False : Binary
        152 :     0 :   0.0 :     1 : False : False : Binary
        153 :     0 :   0.0 :     1 : False : False : Binary
        154 :     0 :   0.0 :     1 : False : False : Binary
        155 :     0 :   0.0 :     1 : False : False : Binary
        156 :     0 :   0.0 :     1 : False : False : Binary
        157 :     0 :   0.0 :     1 : False : False : Binary
        158 :     0 :   0.0 :     1 : False : False : Binary
        159 :     0 :   0.0 :     1 : False : False : Binary
        160 :     0 :   0.0 :     1 : False : False : Binary
        161 :     0 :   0.0 :     1 : False : False : Binary
        162 :     0 :   0.0 :     1 : False : False : Binary
        163 :     0 :   0.0 :     1 : False : False : Binary
        164 :     0 :   0.0 :     1 : False : False : Binary
        165 :     0 :   0.0 :     1 : False : False : Binary
        166 :     0 :   0.0 :     1 : False : False : Binary
        167 :     0 :   0.0 :     1 : False : False : Binary
        168 :     0 :   0.0 :     1 : False : False : Binary
        169 :     0 :   0.0 :     1 : False : False : Binary
        170 :     0 :   0.0 :     1 : False : False : Binary
        171 :     0 :   0.0 :     1 : False : False : Binary
        172 :     0 :   0.0 :     1 : False : False : Binary
        173 :     0 :   0.0 :     1 : False : False : Binary
        174 :     0 :   0.0 :     1 : False : False : Binary
        175 :     0 :   0.0 :     1 : False : False : Binary
        176 :     0 :   0.0 :     1 : False : False : Binary
    g1 : Size=1, Index=None
        Key  : Lower : Value : Upper : Fixed : Stale : Domain
        None :     0 :   1.0 :     1 : False : False : Binary
    h1 : Size=1, Index=None
        Key  : Lower : Value : Upper : Fixed : Stale : Domain
        None :     0 :   1.0 :     1 : False : False : Binary

  Objectives:
    obj : Size=1, Index=None, Active=True
        Key  : Active : Value
        None :   True : 263.52700000000004

  Constraints:
    constraints : Size=12
        Key : Lower : Body    : Upper
          1 :   8.0 :     8.0 :     8.0
          2 :  None :    -1.0 :     0.0
          3 :  None :     0.0 :     0.0
          4 :  None :    -1.0 :     0.0
          5 :  None :     0.0 :     0.0
          6 :  None :    -1.0 :     0.0
          7 :  None :     0.0 :     0.0
          8 :  None :    -1.0 :     0.0
          9 :  None :     0.0 :     0.0
         10 :   1.0 :     2.0 :    None
         11 :  None :     2.0 :     2.0
         12 :  None : 50000.0 : 50000.0
x : Size=177, Index=x_index
    Key : Lower : Value : Upper : Fixed : Stale : Domain
      0 :     0 :   0.0 :     1 : False : False : Binary
      1 :     0 :   0.0 :     1 : False : False : Binary
      2 :     0 :   0.0 :     1 : False : False : Binary
      3 :     0 :   0.0 :     1 : False : False : Binary
      4 :     0 :   0.0 :     1 : False : False : Binary
      5 :     0 :   0.0 :     1 : False : False : Binary
      6 :     0 :   0.0 :     1 : False : False : Binary
      7 :     0 :   0.0 :     1 : False : False : Binary
      8 :     0 :   0.0 :     1 : False : False : Binary
      9 :     0 :   0.0 :     1 : False : False : Binary
     10 :     0 :   0.0 :     1 : False : False : Binary
     11 :     0 :   1.0 :     1 : False : False : Binary
     12 :     0 :   0.0 :     1 : False : False : Binary
     13 :     0 :   0.0 :     1 : False : False : Binary
     14 :     0 :   0.0 :     1 : False : False : Binary
     15 :     0 :   0.0 :     1 : False : False : Binary
     16 :     0 :   0.0 :     1 : False : False : Binary
     17 :     0 :   0.0 :     1 : False : False : Binary
     18 :     0 :   0.0 :     1 : False : False : Binary
     19 :     0 :   0.0 :     1 : False : False : Binary
     20 :     0 :   1.0 :     1 : False : False : Binary
     21 :     0 :   0.0 :     1 : False : False : Binary
     22 :     0 :   0.0 :     1 : False : False : Binary
     23 :     0 :   1.0 :     1 : False : False : Binary
     24 :     0 :   0.0 :     1 : False : False : Binary
     25 :     0 :   0.0 :     1 : False : False : Binary
     26 :     0 :   0.0 :     1 : False : False : Binary
     27 :     0 :   0.0 :     1 : False : False : Binary
     28 :     0 :   0.0 :     1 : False : False : Binary
     29 :     0 :   0.0 :     1 : False : False : Binary
     30 :     0 :   1.0 :     1 : False : False : Binary
     31 :     0 :   0.0 :     1 : False : False : Binary
     32 :     0 :   0.0 :     1 : False : False : Binary
     33 :     0 :   0.0 :     1 : False : False : Binary
     34 :     0 :   0.0 :     1 : False : False : Binary
     35 :     0 :   0.0 :     1 : False : False : Binary
     36 :     0 :   0.0 :     1 : False : False : Binary
     37 :     0 :   0.0 :     1 : False : False : Binary
     38 :     0 :   0.0 :     1 : False : False : Binary
     39 :     0 :   0.0 :     1 : False : False : Binary
     40 :     0 :   0.0 :     1 : False : False : Binary
     41 :     0 :   0.0 :     1 : False : False : Binary
     42 :     0 :   0.0 :     1 : False : False : Binary
     43 :     0 :   0.0 :     1 : False : False : Binary
     44 :     0 :   0.0 :     1 : False : False : Binary
     45 :     0 :   0.0 :     1 : False : False : Binary
     46 :     0 :   0.0 :     1 : False : False : Binary
     47 :     0 :   0.0 :     1 : False : False : Binary
     48 :     0 :   0.0 :     1 : False : False : Binary
     49 :     0 :   0.0 :     1 : False : False : Binary
     50 :     0 :   0.0 :     1 : False : False : Binary
     51 :     0 :   1.0 :     1 : False : False : Binary
     52 :     0 :   0.0 :     1 : False : False : Binary
     53 :     0 :   0.0 :     1 : False : False : Binary
     54 :     0 :   0.0 :     1 : False : False : Binary
     55 :     0 :   0.0 :     1 : False : False : Binary
     56 :     0 :   0.0 :     1 : False : False : Binary
     57 :     0 :   0.0 :     1 : False : False : Binary
     58 :     0 :   0.0 :     1 : False : False : Binary
     59 :     0 :   0.0 :     1 : False : False : Binary
     60 :     0 :   0.0 :     1 : False : False : Binary
     61 :     0 :   0.0 :     1 : False : False : Binary
     62 :     0 :   0.0 :     1 : False : False : Binary
     63 :     0 :   0.0 :     1 : False : False : Binary
     64 :     0 :   0.0 :     1 : False : False : Binary
     65 :     0 :   1.0 :     1 : False : False : Binary
     66 :     0 :   0.0 :     1 : False : False : Binary
     67 :     0 :   0.0 :     1 : False : False : Binary
     68 :     0 :   0.0 :     1 : False : False : Binary
     69 :     0 :   0.0 :     1 : False : False : Binary
     70 :     0 :   0.0 :     1 : False : False : Binary
     71 :     0 :   0.0 :     1 : False : False : Binary
     72 :     0 :   0.0 :     1 : False : False : Binary
     73 :     0 :   0.0 :     1 : False : False : Binary
     74 :     0 :   0.0 :     1 : False : False : Binary
     75 :     0 :   0.0 :     1 : False : False : Binary
     76 :     0 :   0.0 :     1 : False : False : Binary
     77 :     0 :   0.0 :     1 : False : False : Binary
     78 :     0 :   0.0 :     1 : False : False : Binary
     79 :     0 :   0.0 :     1 : False : False : Binary
     80 :     0 :   0.0 :     1 : False : False : Binary
     81 :     0 :   0.0 :     1 : False : False : Binary
     82 :     0 :   0.0 :     1 : False : False : Binary
     83 :     0 :   0.0 :     1 : False : False : Binary
     84 :     0 :   0.0 :     1 : False : False : Binary
     85 :     0 :   0.0 :     1 : False : False : Binary
     86 :     0 :   0.0 :     1 : False : False : Binary
     87 :     0 :   0.0 :     1 : False : False : Binary
     88 :     0 :   0.0 :     1 : False : False : Binary
     89 :     0 :   0.0 :     1 : False : False : Binary
     90 :     0 :   0.0 :     1 : False : False : Binary
     91 :     0 :   0.0 :     1 : False : False : Binary
     92 :     0 :   0.0 :     1 : False : False : Binary
     93 :     0 :   0.0 :     1 : False : False : Binary
     94 :     0 :   0.0 :     1 : False : False : Binary
     95 :     0 :   0.0 :     1 : False : False : Binary
     96 :     0 :   0.0 :     1 : False : False : Binary
     97 :     0 :   0.0 :     1 : False : False : Binary
     98 :     0 :   0.0 :     1 : False : False : Binary
     99 :     0 :   0.0 :     1 : False : False : Binary
    100 :     0 :   0.0 :     1 : False : False : Binary
    101 :     0 :   0.0 :     1 : False : False : Binary
    102 :     0 :   0.0 :     1 : False : False : Binary
    103 :     0 :   0.0 :     1 : False : False : Binary
    104 :     0 :   1.0 :     1 : False : False : Binary
    105 :     0 :   0.0 :     1 : False : False : Binary
    106 :     0 :   0.0 :     1 : False : False : Binary
    107 :     0 :   0.0 :     1 : False : False : Binary
    108 :     0 :   0.0 :     1 : False : False : Binary
    109 :     0 :   0.0 :     1 : False : False : Binary
    110 :     0 :   1.0 :     1 : False : False : Binary
    111 :     0 :   0.0 :     1 : False : False : Binary
    112 :     0 :   0.0 :     1 : False : False : Binary
    113 :     0 :   0.0 :     1 : False : False : Binary
    114 :     0 :   0.0 :     1 : False : False : Binary
    115 :     0 :   0.0 :     1 : False : False : Binary
    116 :     0 :   0.0 :     1 : False : False : Binary
    117 :     0 :   0.0 :     1 : False : False : Binary
    118 :     0 :   0.0 :     1 : False : False : Binary
    119 :     0 :   0.0 :     1 : False : False : Binary
    120 :     0 :   0.0 :     1 : False : False : Binary
    121 :     0 :   0.0 :     1 : False : False : Binary
    122 :     0 :   0.0 :     1 : False : False : Binary
    123 :     0 :   0.0 :     1 : False : False : Binary
    124 :     0 :   0.0 :     1 : False : False : Binary
    125 :     0 :   0.0 :     1 : False : False : Binary
    126 :     0 :   0.0 :     1 : False : False : Binary
    127 :     0 :   0.0 :     1 : False : False : Binary
    128 :     0 :   0.0 :     1 : False : False : Binary
    129 :     0 :   0.0 :     1 : False : False : Binary
    130 :     0 :   0.0 :     1 : False : False : Binary
    131 :     0 :   0.0 :     1 : False : False : Binary
    132 :     0 :   0.0 :     1 : False : False : Binary
    133 :     0 :   0.0 :     1 : False : False : Binary
    134 :     0 :   0.0 :     1 : False : False : Binary
    135 :     0 :   0.0 :     1 : False : False : Binary
    136 :     0 :   0.0 :     1 : False : False : Binary
    137 :     0 :   0.0 :     1 : False : False : Binary
    138 :     0 :   0.0 :     1 : False : False : Binary
    139 :     0 :   0.0 :     1 : False : False : Binary
    140 :     0 :   0.0 :     1 : False : False : Binary
    141 :     0 :   0.0 :     1 : False : False : Binary
    142 :     0 :   0.0 :     1 : False : False : Binary
    143 :     0 :   0.0 :     1 : False : False : Binary
    144 :     0 :   0.0 :     1 : False : False : Binary
    145 :     0 :   0.0 :     1 : False : False : Binary
    146 :     0 :   0.0 :     1 : False : False : Binary
    147 :     0 :   0.0 :     1 : False : False : Binary
    148 :     0 :   0.0 :     1 : False : False : Binary
    149 :     0 :   0.0 :     1 : False : False : Binary
    150 :     0 :   0.0 :     1 : False : False : Binary
    151 :     0 :   0.0 :     1 : False : False : Binary
    152 :     0 :   0.0 :     1 : False : False : Binary
    153 :     0 :   0.0 :     1 : False : False : Binary
    154 :     0 :   0.0 :     1 : False : False : Binary
    155 :     0 :   0.0 :     1 : False : False : Binary
    156 :     0 :   0.0 :     1 : False : False : Binary
    157 :     0 :   0.0 :     1 : False : False : Binary
    158 :     0 :   0.0 :     1 : False : False : Binary
    159 :     0 :   0.0 :     1 : False : False : Binary
    160 :     0 :   0.0 :     1 : False : False : Binary
    161 :     0 :   0.0 :     1 : False : False : Binary
    162 :     0 :   0.0 :     1 : False : False : Binary
    163 :     0 :   0.0 :     1 : False : False : Binary
    164 :     0 :   0.0 :     1 : False : False : Binary
    165 :     0 :   0.0 :     1 : False : False : Binary
    166 :     0 :   0.0 :     1 : False : False : Binary
    167 :     0 :   0.0 :     1 : False : False : Binary
    168 :     0 :   0.0 :     1 : False : False : Binary
    169 :     0 :   0.0 :     1 : False : False : Binary
    170 :     0 :   0.0 :     1 : False : False : Binary
    171 :     0 :   0.0 :     1 : False : False : Binary
    172 :     0 :   0.0 :     1 : False : False : Binary
    173 :     0 :   0.0 :     1 : False : False : Binary
    174 :     0 :   0.0 :     1 : False : False : Binary
    175 :     0 :   0.0 :     1 : False : False : Binary
    176 :     0 :   0.0 :     1 : False : False : Binary